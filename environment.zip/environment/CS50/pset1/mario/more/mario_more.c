#include <stdio.h>
#include <cs50.h>

int main()
{
   int n = 0;
   scanf("%d", &n);

    for(int i=0; i<n; i++){

        for(int j=n-1; j>i ;j--)
            printf(" ");

        for(int k=0;k<=i; k++)
            printf("#");

        printf("  ");

        for(int m=0; m<=i; m++)
            printf("#");


printf("\n");}






}