#include <stdio.h>
#include <cs50.h>

int main()
{
    int n;
    do{
        printf("Unesi broj redova\n");
        n = get_int();

    }while(n<0 || n==0 || n>23);

    for(int i=0; i<n; i++){

        for(int j=n-1; j>i ;j--)
            printf(" ");

            for(int k=0;k<=i; k++)
                printf("#");
        printf("\n");
    }








}