#include <stdio.h>
#include <cs50.h>

int main(){
    int n=0; float k,ch;
    do{
        printf("Unesite kusur:\n");
        get_float()
ch(round(k*100));
    }while(k<0 || k==0);

    for(;k<=0.25;n++)
        k % 0.25 = k;

    for(;k<=0.10;n++)
        k % 0.10 = k;

    for(;k<=0.05;n++)
        k % 0.05 = k;

    for(;k<=0.01;n++)
        k % 0.01 = k;

    printf("Bro kovanica: %d\n",n);
}

