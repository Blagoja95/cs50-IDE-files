#include <stdio.h>
#include <cs50.h>
#include <math.h>

int main (void){
    //UNOS I PROVJERA KUSURA
    int n=0,izlaz; float ulaz;
    do{
        printf("Unesite kusur:\n");
        ulaz=get_float();

    }while(ulaz<0 || ulaz==0);
    //ZAOKRUZIVANJE
    izlaz=round(ulaz*100);

    //BROJAC KOVANICA
for(;izlaz>=25;n++)
    izlaz-=25;

for(;izlaz>=10;n++)
    izlaz-=10;

for(;izlaz>=5;n++)
    izlaz-=5;

for(;izlaz>=1;n++)
    izlaz-=1;

printf(" %d\n", n);

}