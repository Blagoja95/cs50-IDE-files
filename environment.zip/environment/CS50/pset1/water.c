#include <stdio.h>
#include <cs50.h>
int main ()
{
    int minute, boce=12, kal;
    printf("Unesite vrijeme tusiranja\n");
    if(minute <0 || minute==0 || minute>0);{
        minute = get_int();
    }
    else
    {
        printf("Pogresna vrijednost, unesi ponovo\n"); printf("Unesite vrijeme tusiranja\n"); minute=get_int();

    }
    kal = minute*boce;
    printf("Minute = %d \n Boce = %d\n", minute, kal);

}