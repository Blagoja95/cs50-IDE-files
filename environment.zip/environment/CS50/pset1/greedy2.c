#include <stdio.h>
#include <cs50.h>

int main (){
   int t=0; float k;
    do{ printf("Unesite kusur: \n");  k= get_float(); }while(k<0 || k==0);

    while(k>=0.25){k-=0.25;t++;}
    while(k>=0.10){k-=0.10;t++;}
    while(k>=0.05){k-=0.05;t++;}
    while(k>0.01 || k==0.01){k-=0.01;t++;}


    printf("%d\n",t);


}