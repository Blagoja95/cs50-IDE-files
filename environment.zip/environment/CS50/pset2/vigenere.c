#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <cs50.h>


int main(int argc, string argv[]){

    //GETING USER INPUT
    if (argc != 2) // checking if user input have 2 arguments
    {
        printf("ERROR\n Type key, example ./cesar key\n");
        return 1;

    }//DONE

    //CHECKING AND KONVERTING A KEY FROM argv TO key
    string key = (argv[1]);

    for (int i = 0; i < strlen(key); i++)
    {
        if (isalpha(key[i]) == false)
        {
            printf("Key must be alfabetic example: HELLO\n");
            return 1;
        }
    }
         //DONE

    //USER INPUT OF PLAIN TEXT
    printf("Inpuit plain text\n");
    string plaintext = get_string();
    printf("ciphertext: ");

    //CYPHERING
    int k; // key shift  A = 0 and will not shift char but C = 2 and will shift char by two
    int l=0; //position of characte in plaintext
    int j, i; //position in loop

      for (i = 0; i < strlen(plaintext); i++)
    {
        //Encrypt lower case
        if (islower(plaintext[i]))
        {
            j = (l % strlen(key));
            k = (tolower(key[j]) - 97);
            printf("%c", (((plaintext[i] + k) - 97) % 26) + 97);
            l += 1;
        }
        //encrypt upper case
        else if (isupper(plaintext[i]))
        {
            j = (l % strlen(key));
            k = (tolower(key[j]) - 97);
            printf("%c", (((plaintext[i] + k) - 65) % 26) + 65);
            l += 1;
        }
        //print anything else
        else
        {
            printf("%c", plaintext[i]);
        }


    }

    printf("\n");
return 0;



}