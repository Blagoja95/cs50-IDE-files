#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#define MAX 100

//Regulus Arcturus Black
int main(void)
{
    string string = get_string();
    printf("%c", toupper(string[0]));
    for(int i=0, n=strlen(string);i<n;i++)
    {
        if(string[i] == ' ' && string[i] != '\0')
            printf("%c", toupper(string[i+1]));
    }
    printf("\n");



}