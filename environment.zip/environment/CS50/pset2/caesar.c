#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include<stdlib.h>
int main(int argc, string argv [])
{
    int k;
    //KEY
    if (argc != 2) // checking if user input have 2 arguments
    {
        printf("ERROR\n Type key, example ./cesar 2\n");
        return 1;

    }
    else if((k = atoi(argv[1])) < 0) //checking user input to avoid non negativ
    {
        do
        {
            printf("Value is %d, please input non negative value\n", k);
            k = get_int();
        }
        while(k < 0);

    }
//USER INPUT

    printf("Inpuit plain text\n");
    string plaintext = get_string();
    printf("ciphertext: ");

//CYPHERING
    for (int i = 0 ; i < strlen(plaintext); i++)
    {
        if (isalpha(plaintext[i]))
        {
            if (isupper(plaintext[i]))
            {
                plaintext[i] = (((plaintext[i] - 'A' + k) % 26) + 'A');  //or fher gb qevax lbhe Binygvar
            }
            else if (islower (plaintext[i]))
            {
                plaintext[i] = (((plaintext[i] - 'a' + k) % 26) + 'a');
            }

    }

        printf("%c", plaintext[i]);
    }
    printf("\n");

    return 0;
}