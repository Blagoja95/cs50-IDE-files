#define _XOPEN_SOURCE
#include "unistd.h"

#include <stdio.h>
#include <string.h>
#include <cs50.h>

//1. anushree:50xcIMJ0y.RXo = YES
//2. anushree:50xcIMJ0y.RXo = CA
//3. bjbrown:50GApilQSG3E2 = UPenn (takes a while)
//4. lloyd:50n0AAUD.pL8g = lloyd (takes a while)
//5. malan:50CcfIk1QrPr6 = maybe (takes a while)
//6. maria:509nVI8B9VfuA = TF
//7. natmelo:50JIIyhDORqMU = nope
//8. rob:50JGnXUgaafgc = ROFL
//9. stelios:51u8F0dkeDSbY = NO
//10. zamyla:50cI2vYkF0YU2 = LOL


bool crack(string user_input, string guess, string salt);


int main(int argc, string argv[])
{

    //checking for argument in command line
    if (argc != 2)
    {
        printf("Input a Key in argument line\nEXAMPLE: ./crack 89r23234ea44sd\n");
        return 1;
    }

    //converting a password from command line to sting in main
    string hash = (argv[1]);

    char salt[3];

    for (int i = 0; i < 2; i++)
    {
         salt[i] = hash[i];
    }

    salt[2] = '\0';
    char password[6];

    char alpha[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";


    //First Char Pass
    for (int a = 0; a < strlen(alpha); a++)
    {
        password[0] = alpha[a];
        password[1] = '\0';

        if (crack(hash, password, salt))
        {
            printf("Password is: %s\n", password);
            return 0;
        }

    }

//Secund Char Pass
    for (int b = 0; b < strlen(alpha); b++)
        for (int a = 0; a < strlen(alpha); a++)
        {
            password[0] = alpha[a];
            password[1] = alpha[b];
            password[2] = '\0';

            if (crack(hash, password, salt))
            {
                printf("Password is: %s\n", password);
                return 0;
            }

        }

    //Third Char Pass
    for (int c = 0; c < strlen(alpha); c++)
        for (int b = 0; b < strlen(alpha); b++)
            for (int a = 0; a < strlen(alpha); a++)
            {
                password[0] = alpha[a];
                password[1] = alpha[b];
                password[2] = alpha[c];
                password[3] = '\0';

                if(crack(hash, password, salt))
                {
                    printf("Password is: %s\n", password);
                    return 0;
                }
            }

    //Forth Char Pass
    for (int d = 0; d < strlen(alpha); d++)
        for (int c = 0; c < strlen(alpha); c++)
            for (int b = 0; b < strlen(alpha); b++)
                for (int a = 0; a < strlen(alpha); a++)
    {
            password[0] = alpha[a];
            password[1] = alpha[b];
            password[2] = alpha[c];
            password[3] = alpha[d];
            password[4] = '\0';

                if (crack(hash, password, salt))
        {
          printf("Password is: %s\n", password);
          return 0;
        }
    }

    //Fifth char pass
    for(int e = 0; e <strlen(alpha); e++)
        for(int d = 0; d < strlen(alpha); d++)
            for(int c = 0; c < strlen(alpha); c++)
                for(int b = 0; b < strlen(alpha); b++)
                    for(int a = 0; a < strlen(alpha); a++)
    {
            password[0] = alpha[a];
            password[1] = alpha[b];
            password[2] = alpha[c];
            password[3] = alpha[d];
            password[4] = alpha[e];
            password[5] = '\0';

                if (crack(hash, password, salt))
        {
          printf("Password is: %s\n", password);
          return 0;
        }

    }


}

bool crack(string user_input, string guess, string salt)
{
    char *encrypted_guess = crypt(guess, salt);

    if (strcmp(encrypted_guess, user_input) == 0)
    {
        return true;
    }

    return false;
}


