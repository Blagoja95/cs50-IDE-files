#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include<stdlib.h>
int main(int argc, string argv [])
{
    //KEY
    if (argc != 2)
    {
        printf("ERROR\n Type key, example ./cesar 2\n");
        return 1;

    }

//USER INPUT
    int k = atoi(argv[1]);
    printf("Inpuit plain text\n");
    string plaintext = get_string();

//CYPHERING
    for (int i = 0 ; i <= strlen(plaintext); i++)
    {
        if (isalpha (plaintext[i]))
        {
            if (isupper (plaintext[i]))
            {
                plaintext[i]+=k;
                if(plaintext[i] > 90)
                {
                    plaintext[i]-=26;
                    printf("%c", plaintext[i]);
                }
                else
                printf("%c", plaintext[i]);

            }
            else if (islower (plaintext[i]))
            {
                plaintext[i]+=k;
                if(plaintext[i] > 122)
                {
                    plaintext[i]-=26;
                    printf("%c", plaintext[i]);
                }
                else
                printf("%c", plaintext[i]);
            }

    }
        else
        {
            printf("%c", plaintext[i]);
        }
    }
    printf("\n");
//plaintext:  be sure to drink your Ovaltine
//ciphertext: or fher gb qevax lbhe Binygvar
}