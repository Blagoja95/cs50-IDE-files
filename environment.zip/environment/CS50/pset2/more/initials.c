#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>


//Regulus Arcturus Black
int main(void)
{
    string string = get_string();
    for(int i=0,cal=0, n=strlen(string);i<n;i++)
    {
        if(string[i] == ' ' && string[i] != '\0')
        {
                i++;
                cal++;

        }

        else(string[i]!= ' ' && string[i] !='\0')
        {
            printf("%c", string[cal+1]);
        }

    }

    printf("\n");
}