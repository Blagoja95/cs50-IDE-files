from cs50 import get_string
import sys

# checking user input
if len(sys.argv) != 2:
    print("Error, try: python vigenere.py HELLO ")
    sys.exit(1)

# casting second command line argumet as int
key = sys.argv[1]

# cheking if key have only alfabetical characters
for c in key:
    if str.isalpha(c) == False:
        print("Key must be alfabetical, try: HELLO")
        sys.exit(1)

# geting from user plaintext
plaintext = get_string("Input a plaintext: ")

print("ciphertext: ", end="")

l = 0   # position in key

# ciphering users plaintext
for c in plaintext:
    if str.isalpha(c):
        if str.isupper(c):
            n = ord(c)  # getting numeric value char in plaintext
            j = (l % len(key))  # position in k, mod ensure that we loop around the key
            k = ((ord(key[j].lower())) - 97)
            i = ((((n + k) - 65) % 26) + 65)
            o = chr(i)
            print(o, end="")
            l += 1

        elif str.islower(c):
            n = ord(c)  # getting numeric value char in plaintext
            j = (l % len(key))  # position in k, mod ensure that we loop around the key
            k = ((ord(key[j].lower())) - 97)
            i = ((((n + k) - 97) % 26) + 97)
            o = chr(i)
            print(o, end="")
            l += 1

    else:
        print(c, end="")

# end print
print()