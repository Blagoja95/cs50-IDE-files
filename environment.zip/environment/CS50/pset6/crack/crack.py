import crypt
import sys
# crypt.crypt(word, salt)

def main():
# checking user command line input
    if len(sys.argv) != 2:
        print("Error, use: pyton crack.py sh2kasd23")
        sys.exit(2)

    has = sys.argv[1]

    alpha = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"

    password = ""
    for i in range(len(alpha)):
        password[0] = alpha[i]

        if crypt.crypt(has, password):
            print("Password is: {s}", password)
            sys.exit(0)

    # secund pass
    for j in range(len(alpha)):
        for i in range(len(alpha)):
            password[0] = alpha[i]
            password[1] = alpha[j]

            if crypt.crypt(has, password):
                print("Password is: {s}", password)
                sys.exit(0)

    # third pass

    for k in range(len(alpha)):
        for j in range(len(alpha)):
            for i in range(len(alpha)):
                password[0] = alpha[i]
                password[1] = alpha[j]
                password[2] = alpha[k]

                if crypt.crypt(has, password):
                    print("Password is: {s}", password)
                    sys.exit(0)

    # forth pass
    for p in range(len(alpha)):
        for k in range(len(alpha)):
            for j in range(len(alpha)):
                for i in range(len(alpha)):
                    password[0] = alpha[i]
                    password[1] = alpha[j]
                    password[2] = alpha[k]
                    password[3] = alpha[p]

                    if crypt.crypt(has, password):
                        print("Password is: {s}", password)
                        sys.exit(0)

    # fifth pass
    for t in range(len(alpha)):
        for p in range(len(alpha)):
            for k in range(len(alpha)):
                for j in range(len(alpha)):
                    for i in range(len(alpha)):
                        password[0] = alpha[i]
                        password[1] = alpha[j]
                        password[2] = alpha[k]
                        password[3] = alpha[p]
                        password[4] = alpha[t]

                        if crypt.crypt(has, password):
                            print("Password is: {s}", password)
                            sys.exit(0)

main()