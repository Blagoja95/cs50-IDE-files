from cs50 import get_float

# checking users input

while True:
    ul = get_float("Change: ")
    if ul > 0:
        break

# rounding up the number
iz = round(ul * 100)

# number of coins
n = 0

# checking how many coins are needed
while iz >= 25:
    iz -= 25
    n += 1

while iz >= 10:
    iz -= 10
    n += 1

while iz >= 5:
    iz -= 5
    n += 1

while iz >= 1:
    iz -= 1
    n += 1

print(n)