from cs50 import get_string
import sys

# checking user input
if len(sys.argv) != 2:
    print("Error, use: python caesar.py 4 ")
    sys.exit(1)
# casting second command line argumet as int
k = int(sys.argv[1])

# geting from user plaintext
plaintext = get_string("Input a plaintext: ")

print("ciphertext: ", end="")

# ciphering users plaintext
for c in plaintext:
    if str.isalpha(c):
        if str.isupper(c):
            n = ord(c)
            i = (((n - 65 + k) % 26) + 65)
            o = chr(i)
            print(o, end="")

        elif str.islower(c):
            j = ord(c)
            i = (((j - 97 + k) % 26) + 97)
            l = chr(i)
            print(l, end="")

    else:
        print(c, end="")

# end print
print()