from cs50 import get_int

# geting input from the user
while True:
    n = get_int("Input the height of pyramide: ")
    if n >= 1 and n <= 8:
        break

# printing  pyramide
c = 1
j = n - 1

for i in range(n):

    # first half

    # printing spaces
    print(" " * j, end="")

    # printing hashes
    print("#" * c, end="")

    print(" " * 2, end="")

    # printing other half
    print("#" * c, end="")

    # new line
    print()
    c += 1
    j -= 1
