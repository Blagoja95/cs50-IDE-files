from cs50 import get_int

# gettin user input then checking it
while True:
    n = get_int("Input number in range from 1 to 8: ")
    if n >= 1 and n <= 8:
        break

# printing half pyramide
c = 1
j = n - 1
for i in range(n):

    # printing spaces
    print(" " * j, end="")

    # printing hashes
    print("#" * c, end="")

    # new line
    print()
    c += 1
    j -= 1