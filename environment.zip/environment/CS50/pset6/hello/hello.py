from cs50 import get_string

# gettin input from user
s = get_string("NAME: ")

# printing prase with user name
print(f"{s}, hello")