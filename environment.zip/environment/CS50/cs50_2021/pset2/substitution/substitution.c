#include <stdio.h>
#include <cs50.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[])
{
    //checking argument line to see if ther are 2 arguments
    if (argc != 2)
    {
        printf(" ./substitution KEY\n");
        return 1;
    }
    //geting a key
    string key = argv[1];
    //cheking siz of the key
    if (strlen(key) < 26)
    {
        printf(" Key must contain 26 characters.\n");
        return 1;
    }

    for (int i = 0; i <= strlen(key); i++)
    {

        //check fo numbers
        if (isdigit(key[i]))
        {
            printf("Key must only contain alphabetic characters.\n");
            return 1;
        }

        //check for same charakters
        for (int j = 0; j < i; j++)
        {
            if (key[j] == key[i])
            {
                printf(" Key mus not contain repeated characters\n");
                return 1;
            }
        }
    }

    //get a plaintext from the user
    string text = get_string("plaintext:  ");

    //strings of lowercase and uppercase letters to use it for mapping key
    //string lowCase = "abcdefghijklmnopqrstuvwxyz";
    string map = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    printf("ciphertext: ");

    //PRINTING CIPHER
    for (int i = 0; i < strlen(text); i++)
    {

        if (isalpha(text[i]))
        {
            if (isupper(text[i]))
            {
                for (int j = 0; j <= strlen(map); j++)
                {
                    if (map[j] == text[i])
                    {
                        if (isupper(key[j]))
                        {
                            printf("%c", key[j]);
                        }
                        else
                        {
                            char temp = toupper(key[j]);
                            printf("%c", temp);
                        }
                    }
                }

            }
            else
            {
                char temp = toupper(text[i]);
                for (int k = 0; k <= strlen(map); k++)
                {
                    if (map[k] == temp)
                    {
                        if (isupper(key[k]))
                        {
                            char tempA = tolower(key[k]);
                            printf("%c", tempA);
                        }
                        else{

                            printf("%c", key[k]);
                        }
                    }
                }
            }
        }
        else
        {
            printf("%c", text[i]);
        }
    }
}

