#include <stdio.h>
#include <cs50.h>
#include <math.h>
#include <string.h>

void grade(int a, int b, int c);
void wordCounter(string s);

int main(void)
{
    string text = get_string("Type in some text: ");

    wordCounter(text);


}
//counting word, letters and sentences
void wordCounter(string s){

    int word = 0;
    int letter = 0;
    int sentence = 0;

    //checking for how many words and so on
    for(int i = 0, n = strlen(s); i <= n; i++)
    {
        if (s[i] >= 'a' && s[i] <= 'z')
        {
            letter++;
        }
        else if (s[i] >= 'A' && s[i] <= 'Z')
        {
            letter++;
        }
        else if (s[i] == ' ')
        {
            word++;
        }
        else if ( s[i] == '.' || s[i] == '?' || s[i] == '!')
        {
            sentence++;

        }
    }
    //adding one last word
    word++;

    grade(letter, word, sentence);

}
//calculating a grade level
void grade(int a, int b, int c)
{
    //avarage letters per 100 words
    float L = ((float)a / (float)b) * 100;

    //avarage sentence per 100 words
    float S = ((float)c / (float)b) * 100;

    //Cpleman-Liau index
    float result = 0.0588 * L - 0.296 * S - 15.8;

    //grade checking and printing the result
    if (result < 1)
    {
        printf("Before Grade 1\n");
    }
    else if(result > 16)
    {
        printf("Grade 16+\n");

    }
    else
        printf("Grade %i\n", (int) round(result));
}