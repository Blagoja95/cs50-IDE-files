#include <stdio.h>
#include <cs50.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>

void cypher(int k, string text);

int main ( int argc, char *argv[])
{
    int k;

    //checkin user input arguments
    if (argc != 2)
    {
        printf("Missing key. Try ./caesar key\n");
        return 1;
    }
    else if((k = atoi(argv[1])) < 0) //checking user input to avoid non negativ
    {
        printf("Usage ./caesar key\n");
        return 1;

    }

    string plainText = get_string("Type a measage: ");


    cypher(k, plainText);
    return 0;
}
//This function cypher a  measage and then print a cypher
void cypher(int k, string text)
{
    //used to store
    int key = 0;

    printf("ciphertext: ");

    for (int i = 0, n = strlen(text); i <= n; i++)
    {
        if (isalpha(text[i]))
        {
            if(isupper(text[i]))
            {
                printf("%c", ((text[i] - 'A' + k) %26 + 'A'));
            }
            else if (islower(text[i]))
            {
                printf("%c", ((text[i] - 'a' + k) %26 + 'a'));
            }
        }
        else
        printf("%c", text[i]);
    }

    printf("\n");

}
