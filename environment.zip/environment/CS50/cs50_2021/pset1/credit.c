#include <stdio.h>
#include <cs50.h>
#include <string.h>

//max size of number
int MAX = 16;

int main (int argc, char *argv[])
{
    long input = get_long("Number: ");

    int temp[MAX];
    int card[MAX];
    int count = 0;

    //Get each digits into arry
    for (int i = 0; i < MAX; i++)
    {
        if (input > 0)
        {
            temp[i] = input % 10;
            input = input / 10;
            count++;
        }
    }
    //printf("%d ", count);

    //Reverse the arry
    for (int i = count - 1, k = 0; i >= 0; i--, k++)
    {
        card[k] = temp[i];
    }


    //Luhn's Algorithm
    int sum = 0;

    //Multiplaying every other digit by 2
    for (int i = 1; i < count; i += 2)
    {


            temp[i] = temp[i] * 2;
    }
    for (int i = 0; i < count; i++)
    {

        sum += (temp[i] % 10) + (temp[i]/10 % 10);
    }


    //if the last digit is 0 then the card is VALID


    if (sum % 10 != 0)
    {
        printf("INVALID\n");
        return 0;
    }


    //Checking witch type of card is it
    if (count == 15)
    {
        if (card[0] == 3 )
        {
           if ((card[1] == 4 || card[1] == 7))
           {
                    printf("AMEX\n");
           }
           else
           {
               printf("INVALID\n");
           }
        }
        else
        {
            printf("INVALID\n");
        }
    }
    else if ( count >= 13 && count <= 16)
    {
        if (card[0] == 5)
        {
            if ((card[1] == 1 ||  card[1] == 2 || card[1] == 3 || card[1] == 4 || card[1] == 5 ))
            {
                    printf("MASTERCARD\n");
            }
            else
            {
                printf("INVALID\n");
            }
        }
        else if(card[0] == 4)
        {
                printf("VISA\n");
        }
        else
        {
            printf("INVALID\n");
        }
    }
    else
    {
        printf("INVALID\n");
    }



}