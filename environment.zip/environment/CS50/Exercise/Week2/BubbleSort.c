#include<stdio.h>
#include<string.h>

int main(void)
{
    int niz[] = {4, 6, 1, 5, 3, 2, 8, 7};

    for(int i = 0,  n = 8, m = 8 ;  i < n; i++, m--)
    {
        for(int j =0, temp; j < m; j++)
        {
            if (niz[j] > niz[j+1])
            {
                temp = niz[j+1];
                niz[j+1] = niz[j];
                niz[j] = temp;
            }
        }

    }

    for (int i = 0, n = 8; i < n; i++)
    {
        printf("%d ", niz[i]);
    }
    printf("\n");
}